#include <iostream>
#include <vector>
#include <cmath>
#include <limits.h>

using std::cin;
using std::cout;
using std::vector;
using std::pair;

pair<bool, int> check(vector<vector<int>> &board);

class CBot
{
    public:
    bool m_player = 0;
    CBot(bool player): m_player(player) {};
    friend pair<bool, int> check(vector<vector<int>> &board);
    vector<int> minimax(vector<vector<int>> &board, int level, bool player);
    int evalution(vector<vector<int>> &board);
};