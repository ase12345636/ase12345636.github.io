#include <iostream>
#include <vector>

#include "game.h"

using std::cin;
using std::cout;
using std::vector;

int main(int argc, char* argv[])
{
    int mode = 0;
    while(1)
    {
        cout << "Choose mode\n(0:bot v.s bot 1:human v.s bot 2:exit):\n";
        cin >> mode;
        if(mode == 0)
        {
            int round = 0;
            cout << "Please input how may time do you want run:\n";
            cin >> round;
            vector<int> win = botvsbot(round);
            cout << "Bot1 win: " << win[0] << '\n';
            cout << "Bot2 win: " << win[1] << '\n';
            cout << "Even    : " << win[2] << '\n';
        }
        else if(mode == 1)
        {
            bool player = 0;
            cout << "Plese chose O(0) or X(1):";
            cin >> player;
            int win = humanvsbot(player);
            if(win == player)
                cout << "Hunman win\n\n";
            else if(win == !player)
                cout << "Bot win\n\n";
            else
                cout << "Even\n";
        }
        else if(mode == 2)
            break;
        else
            cout << "Invaild mode\n";
    }
}