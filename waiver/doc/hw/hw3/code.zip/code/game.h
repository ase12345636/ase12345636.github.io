#include <vector>

#include "bot.cpp"

using std::vector;
using std::pair;

void showboard(vector<vector<int>> &board)
{
    for(int i = 0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            switch (board[i][j])
            {
            case -1:
                cout << '_' << ' ';
                break;
            case 0:
                cout << 'O' << ' ';
                break;
            case 1:
                cout << 'X' << ' ';
                break;
            default:
                break;
            }
        }
        cout << '\n';
    }
}

vector<int> botvsbot(int round)
{
    vector<int> counter(3, 0);
    for(int i = 0; i < round; i++)
    {
        CBot bot1(0);
        CBot bot2(1);
        cout << "bot1 first\n";
        vector<vector<int>> board = vector<vector<int>>(3, vector<int>(3, -1));
        while(1)
        {
            vector<int> dision = bot1.minimax(board, 10, bot1.m_player);
            board[dision[0]][dision[1]] = bot1.m_player;
            showboard(board);
            pair<bool, int> winner = check(board);
            if(winner.first)
            {
                counter[winner.second]++;
                break;
            }
            dision = bot2.minimax(board, 10, bot2.m_player);
            board[dision[0]][dision[1]] = bot2.m_player;
            showboard(board);
            winner = check(board);
            if(winner.first)
            {
                counter[winner.second]++;
                break;
            }
        }
        cout << "bot2 first\n";
        board = vector<vector<int>>(3, vector<int>(3, -1));
        while(1)
        {
            vector<int> dision = bot2.minimax(board, 9, bot2.m_player);
            board[dision[0]][dision[1]] = bot2.m_player;
            showboard(board);
            pair<bool, int> winner = check(board);
            if(winner.first)
            {
                counter[winner.second]++;
                break;
            }
            dision = bot1.minimax(board, 9, bot1.m_player);
            board[dision[0]][dision[1]] = bot1.m_player;
            showboard(board);
            winner = check(board);
            if(winner.first)
            {
                counter[winner.second]++;
                break;
            }
        }
        cout << "round " << i << " finish\n";
    }
    return counter;
}

int humanvsbot(bool player)
{
    CBot bot1(!player);
    bool turn = 0;
    vector<vector<int>> board = vector<vector<int>>(3, vector<int>(3, -1));
    while(1)
    {
        if(turn == player)
        {
            showboard(board);
            int x = 0, y = 0;
            cin >> x >> y;
            board[x][y] = turn;
        }
        else
        {
            vector<int> desion = bot1.minimax(board, 9, bot1.m_player);
            board[desion[0]][desion[1]] = turn;
        }
        pair<bool, int> winner = check(board);
        if(winner.first)
        {
            showboard(board);
            return winner.second;
        }
        turn = !turn;
    }
}