#include "Bot.h"

pair<bool, int> check(vector<vector <int>> &board)
{
    for(int i = 0; i < 3; i++)
    {
        if(board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][2] == board[i][0] && board[i][0] != -1)
            return {true, board[i][0]};
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != -1)
            return {true, board[0][i]};
    }
    if ((board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != -1) ||
        (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != -1))
        return {true, board[1][1]};
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
            if(board[i][j] == -1)
                return {false, 2};
    return {true, 2};
}

vector<int> CBot::minimax(vector<vector<int>> &board, int level, bool player)
{
    if (check(board).first || level == 0)
        return {-1, -1, evalution(board)};
    else
    {
        if (player == m_player)
        {
            int best_score = INT_MIN;
            pair<int, int> best_pos = {-1, -1};
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i][j] == -1)
                    {
                        board[i][j] = player;
                        int new_score = minimax(board, level - 1, !player)[2];
                        if (new_score > best_score)
                        {
                            best_score = new_score;
                            best_pos = {i, j};
                        }
                        board[i][j] = -1;
                    }
                }
            }
            return {best_pos.first, best_pos.second, best_score};
        }
        else
        {
            int best_score = INT_MAX;
            pair<int, int> best_pos = {-1, -1};
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i][j] == -1)
                    {
                        board[i][j] = player;
                        int new_score = minimax(board, level - 1, !player)[2];
                        if (new_score < best_score)
                        {
                            best_score = new_score;
                            best_pos = {i, j};
                        }
                        board[i][j] = -1;
                    }
                }
            }
            return {best_pos.first, best_pos.second, best_score};
        }
    }
}

int CBot::evalution(vector<vector<int>> &board)
{
    int score = 0;
    for (int i = 0; i < 3; i++)
    {
        int self_cont = 0, opponent_count = 0;
        for (int j = 0; j < 3; j++)
        {
            if (board[i][j] != -1)
            {
                if (board[i][j] == m_player)
                    self_cont++;

                else
                    opponent_count++;
            }
        }
        if (self_cont > 0)
            score += pow(10, self_cont - 1);
        if (opponent_count > 0)
            score -= pow(10, opponent_count - 1);
    }
    for (int i = 0; i < 3; i++)
    {
        int self_cont = 0, opponent_count = 0;
        for (int j = 0; j < 3; j++)
        {
            if (board[j][i] != -1)
            {
                if (board[j][i] == m_player)
                    self_cont++;
                else
                    opponent_count++;
            }
        }
        if (self_cont > 0)
            score += pow(10, self_cont - 1);
        if (opponent_count > 0)
            score -= pow(10, opponent_count - 1);
    }
    for (int i = 0; i < 2; i++)
    {
        int self_cont = 0, opponent_count = 0;
        for (int j = 0; j < 3; j++)
        {
            if (board[j][j + 2 * (i - j) * i] != -1)
            {
                if (board[j][j + 2 * (i - j) * i] == m_player)
                    self_cont++;
                else
                    opponent_count++;
            }
        }
        if (self_cont > 0)
            score += pow(10, self_cont - 1);
        if (opponent_count > 0)
            score -= pow(10, opponent_count - 1);
    }
    return score;
}