import math
import numpy as np
from othello.OthelloUtil import *

class BOT():
    def __init__(self, depth, *args, **kargs):
        self.depth = depth

    def getAction(self, game, color):
        _ , move = alphabeta(game, color, self.depth, -math.inf, math.inf, True)
        move=np.array(move)
        return move

def alphabeta(board, color, depth, alpha, beta, maximizing_player):
    valid_moves = getValidMoves(board, color)
    if depth == 0 or len(valid_moves) == 0:
        return evaluate(board, color), None
    best_move = None
    if maximizing_player:
        max_eval = -math.inf
        for move in valid_moves:
            simulated_board = board.copy()
            executeMove(simulated_board, color, tuple(move))
            eval, _ = alphabeta(simulated_board, -color, depth - 1, alpha, beta, False)
            if eval > max_eval:
                max_eval = eval
                best_move = tuple(move)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval, best_move
    else:
        min_eval = math.inf
        for move in valid_moves:
            simulated_board = board.copy()
            executeMove(simulated_board, color, tuple(move))
            eval, _ = alphabeta(simulated_board, -color, depth - 1, alpha, beta, True)
            if eval < min_eval:
                min_eval = eval
                best_move = tuple(move)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval, best_move

def evaluate(board, color):
    player_count = np.sum(board == color)
    opponent_count = np.sum(board == -color)

    # Corners
    corners = [(0, 0), (0, 5), (5, 0), (5, 5)]
    player_corners = sum([1 for corner in corners if board[corner[0], corner[1]] == color])
    opponent_corners = sum([1 for corner in corners if board[corner[0], corner[1]] == -color])

    # Stability
    stability_matrix = np.array([
        [ 4, -3,  2,  2, -3,  4],
        [-3, -4, -1, -1, -4, -3],
        [ 2, -1,  1,  1, -1,  2],
        [ 2, -1,  1,  1, -1,  2],
        [-3, -4, -1, -1, -4, -3],
        [ 4, -3,  2,  2, -3,  4]
    ])
    player_stability = np.sum(stability_matrix * (board == color))
    opponent_stability = np.sum(stability_matrix * (board == -color))

    # Mobility
    player_mobility = len(getValidMoves(board, color))
    opponent_mobility = len(getValidMoves(board, -color))

    # Weighted evaluation
    score = 10 * (player_count - opponent_count) + \
            10 * (player_corners - opponent_corners) + \
            5 * (player_stability - opponent_stability) + \
            (player_mobility - opponent_mobility)
    return score