from othello.OthelloGame import OthelloGame, BLACK, WHITE
from othello.bots.AlphaBeta import BOT as AlphaBetaPlayer
from othello.bots.AlphaBeta2 import BOT as AlphaBetaPlayer2

borad_size = 6

def self_play(black, white, verbose=True):
    g = OthelloGame(n=borad_size)
    result = g.play(black, white, verbose)
    return result

def dual(n_game, bot1, bot2, bot1_name='' ,bot2_name=''):
    print(f'{bot1_name} VS {bot2_name}'.center(76))
    bot1_win = 0
    bot2_win = 0
    for i in range(n_game):
        print("Game {}".format(i+1))
        result = self_play(bot1, bot2, verbose=True)
        if result == BLACK:
            print('\033[92m' + f'{bot1_name} won!' + '\033[0m')
            bot1_win += 2
        elif result == WHITE:
            print('\033[92m' + f'{bot2_name} won!' + '\033[0m')
            bot2_win += 2
        else:
            print("Draw")
            bot1_win += 1
            bot2_win += 1

        result = self_play(bot2, bot1, verbose=True)
        if result == BLACK:
            print('\033[92m' + f'{bot2_name} won!' + '\033[0m')
            bot2_win += 2
        elif result == WHITE:
            print('\033[92m' + f'{bot1_name} won!' + '\033[0m')
            bot1_win += 2
        else:
            print("Draw")
            bot1_win += 1
            bot2_win += 1
        print("{} win: {}".format(bot1_name, bot1_win))
        print("{} win: {}".format(bot2_name, bot2_win))
        print("----------------------------------------------------------------------------")


def main():
    bot1_name = "Alpha Beta"
    bot1 = AlphaBetaPlayer(6)
    bot2_name = "Alpha Beta"
    bot2 = AlphaBetaPlayer2(6)
    dual(n_game=5,
         bot1=bot1,
         bot1_name=bot1_name,
         bot2=bot2,
         bot2_name=bot2_name)


if __name__ == '__main__':
    main()
