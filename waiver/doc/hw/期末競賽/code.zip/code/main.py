from AIGamePlatform import Othello
from othello.bots.AlphaBeta import BOT

app=Othello() # 和平台建立WebSocket連線
bot=BOT(6)

@app.competition(competition_id='1131決賽') # 競賽ID
def _callback_(board, color): # 當需要走步會收到盤面及我方棋種
    return bot.getAction(board, color) # bot回傳落子座標

