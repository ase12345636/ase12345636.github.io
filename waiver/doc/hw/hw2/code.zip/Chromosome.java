public class Chromosome
{
    static int defaultGeneLength = 64;
    private byte[] genes = new byte[defaultGeneLength];
    private double fitness = 0;

    public void generateChromosome()    // Create a random individual
    {
        for (int i = 0; i < size(); i++)
        {
            if(i == 0)
            {
                byte gene = (byte) Math.round(Math.random() * 128);
                genes[i] = gene;
            }
            else
            {
                byte gene = (byte) Math.round(Math.random() * 256 - 128);
                genes[i] = gene;
            }
        }
    }

    public static void setDefaultGeneLength(int length)
    {
        defaultGeneLength = length;
    }
    
    public byte getGene(int index)
    {
        return genes[index];
    }

    public void setGene(int index, byte value)
    {
        genes[index] = value;
        fitness = 0;
    }

    public int size()
    {
        return genes.length;
    }

    public double getFitness()
    {
        if (fitness == 0)
        {
            fitness = Fitness.getFitness(this);
        }
        
        return fitness;
    }

    public String toString()
    {
        String geneString = "";
        
        for (int i = 0; i < size(); i++)
        {
            geneString += (getGene(i) + "");
        }
        
        return geneString;
    }
    public byte[] getChromosome()
    {
        return genes;
    }
}