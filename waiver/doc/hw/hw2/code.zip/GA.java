import java.nio.ByteBuffer;
import java.util.Scanner;

public class GA
{
    /* GA parameters */
    private static final double uniformRate = 0.5;
    private static final double mutationRate = 0.5;
    private static final int tournamentSize = 5;
    private static final boolean elitism = true;

    public static Population evolvePopulation(Population pop)    // Evolve a population
    {
        Population newPopulation = new Population(pop.size(), false);

        // Keep our best individual
        if (elitism)
        {
            newPopulation.saveChromosome(0, pop.getFittest());
        }

        // Crossover population
        int elitismOffset;
        if (elitism)
        {
            elitismOffset = 1;
        }
        else
        {
            elitismOffset = 0;
        }
        // Create new chromosomes with crossover
        for (int i = elitismOffset; i < pop.size(); i++)
        {
            Chromosome indiv1 = tournamentSelection(pop);
            Chromosome indiv2 = tournamentSelection(pop);
            Chromosome newIndiv = crossover(indiv1, indiv2);
            newPopulation.saveChromosome(i, newIndiv);
        }

        // Mutate population
        for (int i = elitismOffset; i < newPopulation.size(); i++)
        {
            mutate(newPopulation.chromosomes[i]);
        }

        return newPopulation;
    }

    // Crossover individuals
    private static Chromosome crossover(Chromosome indiv1, Chromosome indiv2)
    {
        Chromosome newSol = new Chromosome();
        
        for (int i = 0; i < indiv1.size(); i++)
        {
            // Crossover
            if (Math.random() <= uniformRate)
            {
                newSol.setGene(i, indiv1.getGene(i));
            }
            else
            {
                newSol.setGene(i, indiv2.getGene(i));
            }
        }
        
        return newSol;
    }

    // Mutate an individual
    private static void mutate(Chromosome indiv)
    {
        for (int i = 0; i < indiv.size(); i++)
        {
            if (Math.random() <= mutationRate)
            {
                if (i == 0)
                {
                    byte gene = (byte) (Math.random() * 128);
                    indiv.setGene(i, gene);
                }
                else
                {
                    byte gene = (byte) (Math.random() * 256 - 128);
                    indiv.setGene(i, gene);
                }
            }
        }
    }

    // Select individuals for crossover
    private static Chromosome tournamentSelection(Population pop)
    {
        // Create a tournament population
        Population tournament = new Population(tournamentSize, false);
        // For each place in the tournament get a random individual
        for (int i = 0; i < tournamentSize; i++) 
        {
            int randomId = (int) (Math.random() * pop.size());
            tournament.saveChromosome(i, pop.chromosomes[randomId]);
        }
        // Get the fittest
        Chromosome fittest = tournament.getFittest();
        
        return fittest;
    }
    
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        double num = stdin.nextDouble();
        stdin.close();

        // Set a candidate solution
        Fitness.setSolution(num);

        // Create an initial population
        Population myPop = new Population(50, true);
        
        // Evolve our population until we reach an optimum solution
        int generationCount = 0;
        while (myPop.getFittest().getFitness() >= Fitness.getMinFitness())
        {
            generationCount++;
            System.out.println("Generation: " + generationCount + " Fittest: " + myPop.getFittest().getFitness());
            myPop = GA.evolvePopulation(myPop);
        }
        System.out.println("Solution found!");
        System.out.println("Generation: " + generationCount);
        System.out.println("Genes:");
        System.out.println(ByteBuffer.wrap(myPop.getFittest().getChromosome()).getDouble());

    }
}