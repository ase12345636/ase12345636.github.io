public class Population
{
    Chromosome[] chromosomes;

    public Population(int populationSize, boolean initialise)    // Create a population
    {
        chromosomes = new Chromosome[populationSize];

        if (initialise)        // Initialize population
        {
            for (int i = 0; i < size(); i++)            // Create chromosomes
            {
                Chromosome newChromosome = new Chromosome();
                newChromosome.generateChromosome();
                saveChromosome(i, newChromosome);
            }
        }
    }

    public Chromosome getFittest()
    {
        Chromosome fittest = chromosomes[0];

        for (int i = 0; i < size(); i++)        // Find fittest
        {
            if (fittest.getFitness() > chromosomes[i].getFitness())
            {
                fittest = chromosomes[i];
            }
        }
        
        return fittest;
    }

    public int size()    // Get population size
    {
        return chromosomes.length;
    }

    public void saveChromosome(int index, Chromosome chrom)    // Save chromosome
    {
        chromosomes[index] = chrom;
    }
}