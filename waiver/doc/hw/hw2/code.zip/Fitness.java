import java.nio.ByteBuffer;

public class Fitness
{
    static double solution = 0;

    public static void setSolution(double newSolution)    // Set a candidate solution as a byte array
    {
        solution = newSolution;
    }

    static double getFitness(Chromosome chromosome)    // Calculate chromosome's fittness by comparing it to our candidate solution
    {
        double chromosomeDouble = ByteBuffer.wrap(chromosome.getChromosome()).getDouble();
        chromosomeDouble = (chromosomeDouble * chromosomeDouble);

        return Math.abs(solution - chromosomeDouble);
    }
    
    static double getMinFitness()    // Get optimum fitness
    {
        return 0.0000000000001;
    }
}