// 請幫我用backtracking的方法解數獨，如果有解幫我印出解題時間

#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

#define N 9

bool isSafe(int grid[N][N], int row, int col, int num) {
    for (int x = 0; x < N; x++) {
        if (grid[row][x] == num || grid[x][col] == num) {
            return false;
        }
    }

    int startRow = row - row % 3, startCol = col - col % 3;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (grid[i + startRow][j + startCol] == num) {
                return false;
            }
        }
    }

    return true;
}

bool solveSudoku(int grid[N][N], int row, int col) {
    if (row == N - 1 && col == N) {
        return true;
    }

    if (col == N) {
        row++;
        col = 0;
    }

    if (grid[row][col] != 0) {
        return solveSudoku(grid, row, col + 1);
    }

    for (int num = 1; num <= N; num++) {
        if (isSafe(grid, row, col, num)) {
            grid[row][col] = num;
            if (solveSudoku(grid, row, col + 1)) {
                return true;
            }
            grid[row][col] = 0;
        }
    }

    return false;
}

void printGrid(int grid[N][N]) {
    for (int row = 0; row < N; row++) {
        for (int col = 0; col < N; col++) {
            cout << grid[row][col] << " ";
        }
        cout << endl;
    }
}

int main() {
    int grid[N][N] = {
        {0, 0, 0, 8, 0, 6, 0, 0, 0},
        {0, 0, 0, 0, 2, 0, 0, 7, 0},
        {0, 0, 9, 4, 0, 0, 5, 0, 0},
        {4, 0, 0, 0, 0, 0, 3, 0, 6},
        {3, 0, 0, 0, 0, 0, 0, 0, 0},
        {2, 6, 0, 0, 0, 1, 7, 0, 0},
        {9, 3, 5, 0, 1, 0, 0, 4, 0},
        {0, 0, 0, 5, 0, 8, 2, 0, 0},
        {0, 0, 0, 0, 0, 3, 0, 1, 0}
    };

    auto start = high_resolution_clock::now();

    if (solveSudoku(grid, 0, 0)) {
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        cout << "Sudoku solved in " << duration.count() << " microseconds" << endl;
        printGrid(grid);
    } else {
        cout << "No solution exists" << endl;
    }

    return 0;
}